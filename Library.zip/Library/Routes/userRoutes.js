const express = require("express");
const router = express.Router();
const { register, login, addToCart } = require("../controllers/userController");
const authMiddleware = require("../Middleware/authMiddleware");

router.post("/register", register);
router.post("/login", login);
router.post("/cart", authMiddleware, addToCart);

module.exports = router;