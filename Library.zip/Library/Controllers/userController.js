const User = require("../models/User");
const Book = require("../models/Book");
const Cart = require("../models/Cart");
const Borrow = require("../models/Borrow");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");
const { registerSchema, loginSchema } = require("../validation/userValidation");
const { addToCartSchema } = require("../validation/cartValidation");

const register = async (req,res) => {
  try {
    const { error, value } = registerSchema.validate(req.body);
    if(error) return res.status(400).json({ msg: error.details.map(e=>e.message) });

    const exist = await User.findOne({ email: value.email });
    if(exist) return res.status(400).json({ msg:"User Exists" });

    value.password = await bcrypt.hash(value.password,10);
    const user = await User.create(value);

    res.status(201).json({ msg: "User Registered", user });
  } catch(err) {
    res.status(500).json({ msg: "Server Error" });
  }
}

const login = async (req,res) => {
  try {
    const { error, value } = loginSchema.validate(req.body);
    if(error) return res.status(400).json({ msg: error.details.map(e=>e.message) });

    const user = await User.findOne({ email: value.email });
    if(!user) return res.status(400).json({ msg:"User Not Found" });

    const match = await bcrypt.compare(value.password, user.password);
    if(!match) return res.status(400).json({ msg:"Invalid Password" });

    const token = jwt.sign({ id:user._id, role:user.role }, process.env.JWT_SK, { expiresIn: "1d" });
    res.status(200).json({ msg:"Login Success", token });
  } catch(err) {
    res.status(500).json({ msg: "Server Error" });
  }
}

// Cart
const addToCart = async (req,res) => {
  try {
    const { error, value } = addToCartSchema.validate(req.body);
    if(error) return res.status(400).json({ msg: error.details.map(e=>e.message) });

    let cart = await Cart.findOne({ user: req.user });
    if(!cart) cart = await Cart.create({ user: req.user, books: [], totalPrice: 0 });

    const book = await Book.findById(value.bookId);
    if(!book) return res.status(404).json({ msg:"Book Not Found" });

    cart.books.push(book._id);
    cart.totalPrice += book.price;
    await cart.save();

    res.status(200).json({ msg:"Book Added to Cart", cart });
  } catch(err) {
    res.status(500).json({ msg: "Server Error" });
  }
}

module.exports = { register, login, addToCart };